package br.com.openinsurance.insptyopindynamicfieldsbe.repository;

import br.com.openinsurance.insptyopindynamicfieldsbe.model.entity.Branch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BranchRepository extends JpaRepository<Branch, Long> {
}