package br.com.openinsurance.insptyopindynamicfieldsbe.model.dto.response;

import lombok.Data;

@Data
public class Links {
    private String next;
    private String last;
    private String prev;
    private String self;
    private String first;
}