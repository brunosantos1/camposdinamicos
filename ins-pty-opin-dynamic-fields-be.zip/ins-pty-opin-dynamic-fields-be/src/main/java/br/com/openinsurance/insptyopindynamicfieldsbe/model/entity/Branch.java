package br.com.openinsurance.insptyopindynamicfieldsbe.model.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Set;


@Entity
@Getter
@Setter
@Table(name = "tbRamoQuestionario", schema = "smOpin")
public class Branch {

    @Id
    @Column(name = "idRamoQuestionario", nullable = false, updatable = false)
    @SequenceGenerator(
            name = "tbRamoQuestionario_idRamoQuestionario_seq",
            sequenceName = "tbRamoQuestionario_idRamoQuestionario_seq",
            schema = "smOpin",
            allocationSize = 1)
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "tbRamoQuestionario_idRamoQuestionario_seq"
    )
    private Long id;

    @Column(name = "dsCodigoRamo", nullable = false, length = 4)
    private String code;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idQuestionario", nullable = false)
    private Questionnaire questionnaire;

    @OneToMany(mappedBy = "branch")
    private Set<Field> fields;

}
