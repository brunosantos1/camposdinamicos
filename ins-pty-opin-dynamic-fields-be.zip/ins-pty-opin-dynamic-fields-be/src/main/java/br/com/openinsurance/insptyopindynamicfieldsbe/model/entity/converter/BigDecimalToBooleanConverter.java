package br.com.openinsurance.insptyopindynamicfieldsbe.model.entity.converter;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import java.math.BigDecimal;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static java.math.BigDecimal.ONE;
import static java.math.BigDecimal.ZERO;

@Converter
public class BigDecimalToBooleanConverter implements AttributeConverter<Boolean, BigDecimal> {

    @Override
    public BigDecimal convertToDatabaseColumn(Boolean attribute) {
        return TRUE.equals(attribute) ? ONE : ZERO;
    }

    @Override
    public Boolean convertToEntityAttribute(BigDecimal dbData) {
        return ONE.equals(dbData) ? TRUE : FALSE;
    }
}