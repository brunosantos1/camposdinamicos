package br.com.openinsurance.insptyopindynamicfieldsbe.model.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Set;
import java.util.UUID;


@Entity
@Getter
@Setter
@Table(name = "tbEmpresa", schema = "smOpin")
public class Company {

    @Id
    @Column(name = "idEmpresa", nullable = false, updatable = false)
    @SequenceGenerator(
            name = "tbEmpresa_idEmpresa_seq",
            sequenceName = "tbEmpresa_idEmpresa_seq",
            schema = "smOpin",
            allocationSize = 1)
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "tbEmpresa_idEmpresa_seq"
    )
    private Long id;

    @Column(name = "idPublicoEmpresa", nullable = false)
    private UUID tenantId;

    @Column(name = "nome", nullable = false, length = 100)
    private String name;

    @OneToMany(mappedBy = "company")
    private Set<Questionnaire> companyQuestionnaires;

}
