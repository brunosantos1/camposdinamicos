#!groovy
@Library('build-lib@hdi-compiler-java') _
buildDev javaVersion: 17