package br.com.openinsurance.insptyopindynamicfieldsbe.service;

import br.com.openinsurance.insptyopindynamicfieldsbe.model.entity.Questionnaire;
import br.com.openinsurance.insptyopindynamicfieldsbe.repository.QuestionnaireRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class DynamicFieldService {
    final QuestionnaireRepository questionnaireRepository;

    @Transactional(readOnly = true)
    public List<Questionnaire> getDynamicFields(Pageable pageable) {
        List<Questionnaire> questionnaires =  questionnaireRepository.findAll(pageable).getContent();
        log.info("Questionnaires: {}", questionnaires);
		return questionnaires;
    }

}
