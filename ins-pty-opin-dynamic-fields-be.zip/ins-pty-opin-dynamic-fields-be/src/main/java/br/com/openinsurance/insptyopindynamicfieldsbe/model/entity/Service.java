package br.com.openinsurance.insptyopindynamicfieldsbe.model.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Set;


@Entity
@Getter
@Setter
@Table(name = "tbServico", schema = "public")
public class Service {

    @Id
    @Column(name = "idServico", nullable = false, updatable = false)
    @SequenceGenerator(
            name = "tbServico_idServico_seq",
            sequenceName = "tbServico_idServico_seq",
            schema = "smOpin",
            allocationSize = 1)
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "tbServico_idServico_seq"
    )
    private Long id;

    @Column(name = "nmServiço", nullable = false, length = 100)
    private String name;

    @OneToMany(mappedBy = "service")
    private Set<Questionnaire> questionnaires;

}
