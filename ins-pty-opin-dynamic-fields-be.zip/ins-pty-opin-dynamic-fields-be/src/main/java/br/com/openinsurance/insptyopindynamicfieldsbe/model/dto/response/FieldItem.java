package br.com.openinsurance.insptyopindynamicfieldsbe.model.dto.response;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
public class FieldItem extends Field {
    private String category;
    private List<Field> items;
}