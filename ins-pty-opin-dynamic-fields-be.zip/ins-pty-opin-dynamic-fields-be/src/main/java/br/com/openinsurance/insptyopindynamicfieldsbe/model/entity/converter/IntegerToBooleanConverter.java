package br.com.openinsurance.insptyopindynamicfieldsbe.model.entity.converter;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

@Converter
public class IntegerToBooleanConverter implements AttributeConverter<Boolean, Integer> {

    @Override
    public Integer convertToDatabaseColumn(Boolean attribute) {
        return TRUE.equals(attribute) ? 1 : 0;
    }

    @Override
    public Boolean convertToEntityAttribute(Integer dbData) {
        return Integer.valueOf(1).equals(dbData) ? TRUE : FALSE;
    }
}