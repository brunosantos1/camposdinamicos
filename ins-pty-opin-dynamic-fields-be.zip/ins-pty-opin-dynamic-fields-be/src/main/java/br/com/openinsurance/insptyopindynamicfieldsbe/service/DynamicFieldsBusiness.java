package br.com.openinsurance.insptyopindynamicfieldsbe.service;

import br.com.openinsurance.insptyopindynamicfieldsbe.model.dto.response.DynamicFieldsResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class DynamicFieldsBusiness {


    public DynamicFieldsResponse getDynamicFields() {

        return null;
    }


}
