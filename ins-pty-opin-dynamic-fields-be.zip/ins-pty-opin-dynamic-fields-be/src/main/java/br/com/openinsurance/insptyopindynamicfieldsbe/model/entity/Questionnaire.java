package br.com.openinsurance.insptyopindynamicfieldsbe.model.entity;

import br.com.openinsurance.insptyopindynamicfieldsbe.model.entity.converter.BigDecimalToBooleanConverter;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Set;


@Entity
@Getter
@Setter
@Table(name = "tbQuestionario", schema = "public")
public class Questionnaire {

    @Id
    @Column(name = "idQuestionario", nullable = false, updatable = false)
    @SequenceGenerator(
            name = "tbQuestionario_idQuestionario_seq",
            sequenceName = "tbQuestionario_idQuestionario_seq",
            schema = "opin",
            allocationSize = 1)
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "tbQuestionario_idQuestionario_seq"
    )
    private Long id;

    @Convert(converter = BigDecimalToBooleanConverter.class)
    @Column(name = "fgAtivo", nullable = false, length = 1, columnDefinition = "NUMERIC(1)")
    private Boolean isEnable;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idServico", nullable = false)
    private Service service;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idEmpresa", nullable = false)
    private Company company;

    @OneToMany(mappedBy = "questionnaire")
    private Set<Branch> branches;

}
