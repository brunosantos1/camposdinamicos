package br.com.openinsurance.insptyopindynamicfieldsbe.repository;

import br.com.openinsurance.insptyopindynamicfieldsbe.model.entity.Questionnaire;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuestionnaireRepository extends JpaRepository<Questionnaire, Long> {

}