#!groovy
@Library('build-lib@hdi-compiler-java') _
buildHml javaVersion: 17