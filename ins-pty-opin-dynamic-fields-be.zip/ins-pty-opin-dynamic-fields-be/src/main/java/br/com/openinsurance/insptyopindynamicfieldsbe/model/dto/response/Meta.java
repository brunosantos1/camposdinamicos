package br.com.openinsurance.insptyopindynamicfieldsbe.model.dto.response;

import lombok.Data;

@Data
public class Meta {
    private Integer totalRecords;
    private Integer totalPages;
}