package br.com.openinsurance.insptyopindynamicfieldsbe.controller;

import br.com.openinsurance.insptyopindynamicfieldsbe.model.entity.Questionnaire;
import br.com.openinsurance.insptyopindynamicfieldsbe.service.DynamicFieldService;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("")
public class DynamicFieldsController {

	@Autowired
	final DynamicFieldService fieldService;

    @GetMapping("/damage-and-person")
    public List<Questionnaire> getDamageAndPerson(
		@RequestHeader(value = "Authorization", required = false) String authorization,
		@RequestHeader(value = "x-fapi-auth-date", required = false) String xFapiAuthDate,
		@RequestHeader(value = "x-fapi-customer-ip-address", required = false) String xFapiCustomer,
		@RequestHeader(value = "x-fapi-interaction-id", required = false) String xFapiInteractionId,
		@RequestHeader(value = "x-customer-user-agent", required = false) String xCustomerUserAgent,
		@RequestParam(value = "page", required = false) int page,
		@RequestParam(value = "page-size", required = false) int pageSize
	) {
        Pageable pageable = PageRequest.of(page, pageSize);
		return fieldService.getDynamicFields(pageable);
		 
    }

}