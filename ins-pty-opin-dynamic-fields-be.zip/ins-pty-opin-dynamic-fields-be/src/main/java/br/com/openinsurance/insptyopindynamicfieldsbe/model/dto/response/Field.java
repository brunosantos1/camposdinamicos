package br.com.openinsurance.insptyopindynamicfieldsbe.model.dto.response;

import lombok.Data;

@Data
public class Field {
    private String name;
    private String format;
    private String type;
    private Integer maxLength;
    private String fieldId;
    private String example;
}
