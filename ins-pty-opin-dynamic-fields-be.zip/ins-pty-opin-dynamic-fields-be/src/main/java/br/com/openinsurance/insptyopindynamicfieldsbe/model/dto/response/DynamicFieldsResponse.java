package br.com.openinsurance.insptyopindynamicfieldsbe.model.dto.response;

import lombok.Data;

import java.util.List;

@Data
public class DynamicFieldsResponse {
    private List<DynamicField> data;
    private Meta meta;
    private Links links;
}