package br.com.openinsurance.insptyopindynamicfieldsbe.repository;

import br.com.openinsurance.insptyopindynamicfieldsbe.model.entity.Service;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceRepository extends JpaRepository<Service, Long> {
}