package br.com.openinsurance.insptyopindynamicfieldsbe.model.entity;

import br.com.openinsurance.insptyopindynamicfieldsbe.model.entity.converter.BigDecimalToBooleanConverter;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.SQLSelect;

import java.util.Set;
import java.util.UUID;


@Entity
@Getter
@Setter
@Table(name = "tbCampoDinamico", schema = "smOpin")
public class Field {

    @Id
    @Column(name = "idCampoDinamico", nullable = false, updatable = false)
    @SequenceGenerator(
            name = "tbRamoQuestionario_idCampoDinamico_seq",
            sequenceName = "tbRamoQuestionario_idCampoDinamico_seq",
            schema = "smOpin",
            allocationSize = 1)
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "tbRamoQuestionario_idCampoDinamico_seq"
    )
    private Long id;

    @Column(name = "idPublicoCampoDinamico", nullable = false)
    private UUID fieldId;

    @Column(name = "nome", nullable = false, length = 100)
    private String name;

    @Column(name = "dsTipo", nullable = false, length = 10)
    private String type;

    @Column(name = "dsCategoria", length = 100)
    private String category;

    @Column(name = "dsFormato", length = 10)
    private String format;

    @Column(name = "dsExemplo", length = 100)
    private String example;

    @Column(name = "nrTamanhoMaximoResposta")
    private Integer maxLength;

    @Convert(converter = BigDecimalToBooleanConverter.class)
    @Column(name = "flLista", nullable = false, length = 1, columnDefinition = "NUMERIC(1)")
    private Boolean isArray;

    @Convert(converter = BigDecimalToBooleanConverter.class)
    @Column(name = "flAtivo", nullable = false, length = 1, columnDefinition = "NUMERIC(1)")
    private Boolean isEnable;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idRamoQuestionario", nullable = false)
    private Branch branch;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idCampoDinamicoPai")
    private Field parentField;

    @OneToMany(mappedBy = "parentField")
    private Set<Field> parentFields;

}
