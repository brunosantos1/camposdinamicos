package br.com.openinsurance.insptyopindynamicfieldsbe.model.dto.response;

import lombok.Data;

import java.util.List;

@Data
public class DynamicField {
    private String api;
    private List<BranchItem> branch;
}