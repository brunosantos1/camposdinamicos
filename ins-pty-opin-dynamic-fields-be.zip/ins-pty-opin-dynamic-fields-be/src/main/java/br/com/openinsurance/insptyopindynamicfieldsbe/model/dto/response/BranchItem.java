package br.com.openinsurance.insptyopindynamicfieldsbe.model.dto.response;

import java.util.List;
import lombok.Data;

@Data
public class BranchItem{
	private String code;
	private List<FieldItem> fields;
}